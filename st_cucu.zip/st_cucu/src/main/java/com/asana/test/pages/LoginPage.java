package com.asana.test.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage {

    @FindBy(css = "input[type='email']")
    private WebElement emailInput;

    @FindBy(css = "input[type='password']")
    private WebElement passwordInput;

    @FindBy(css = "button[type='submit']")
    private WebElement submitButton;

    public void navigateToLoginPage() {
        driver.get("https://app.asana.com/-/login");
    }

    public void enterEmail(String email) {
        waitForElementToBeVisible(emailInput);
        emailInput.clear();
        emailInput.sendKeys(email);
    }

    public void clickContinueButton() {
        waitForElementToBeClickable(submitButton);
        submitButton.click();
    }

    public void enterPassword(String password) {
        waitForElementToBeVisible(passwordInput);
        passwordInput.clear();
        passwordInput.sendKeys(password);
    }

    public void clickLoginButton() {
        waitForElementToBeClickable(submitButton);
        submitButton.click();
    }

    public void login(String email, String password) {
        enterEmail(email);
        clickContinueButton(); // Needed before entering password
        enterPassword(password);
        clickLoginButton();
    }
}
