package com.asana.test.steps;

import com.asana.test.pages.LoginPage;
import io.cucumber.java.en.*;

public class LoginSteps {
    private LoginPage loginPage = new LoginPage();

    @Given("I am on the Asana login page")
    public void i_am_on_the_asana_login_page() {
        loginPage.navigateToLoginPage();
    }

    @When("I enter valid email {string}")
    public void i_enter_valid_email(String email) {
        loginPage.enterEmail(email);
    }

    @When("I enter valid password {string}")
    public void i_enter_valid_password(String password) {
        loginPage.enterPassword(password);
    }

    @When("I click the continue button")
    public void i_click_the_continue_button() {
        loginPage.clickContinueButton();
    }

    @When("I click the login button")
    public void i_click_the_login_button() {
        loginPage.clickLoginButton();
    }

    @Then("I should be logged in successfully")
    public void i_should_be_logged_in_successfully() throws InterruptedException {
        // Wait for the dashboard to load and verify we're logged in
        Thread.sleep(5000); // Wait for page load
        // Add more specific verification if needed
        System.out.println("Successfully logged in to Asana");
    }

    @When("I enter invalid email {string}")
    public void i_enter_invalid_email(String email) {
        loginPage.enterEmail(email);
    }

    @When("I enter invalid password {string}")
    public void i_enter_invalid_password(String password) {
        loginPage.enterPassword(password);
    }

    @Then("I should see an error message")
    public void i_should_see_an_error_message() {
        // Add verification logic here
        // This could involve checking for error message elements
    }
}
