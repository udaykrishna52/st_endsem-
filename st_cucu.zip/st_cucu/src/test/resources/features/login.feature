@login
Feature: Asana Login Functionality
  As a user
  I want to be able to login to Asana automatically
  So that I can access my tasks and projects

  @auto_login
  Scenario: Automatic login with valid credentials
    Given I am on the Asana login page
    When I enter valid email "ankutarish06@gmail.com"
